<?php
session_start();
$_SESSION['$Serial_Id'] = $_GET['updateid'];
?>


<!DOCTYPE html>
<html>
<head>
    <title>Review Page</title>
    <link rel="stylesheet" href="../views/css/history.css">

</head>
<body>
    <form method="post" action="../models/index.php">
            <center>
    <table  width="500px">
        <tr>
            <td>
                <table width="500px">
                    <tr>
                        <td align="Left">
                <h3><b>Customer Review</b></h3>
            </td>
            <td align="Right">
                <a href="#">Add Review</a> |
                <a href="deleteReview.php">Delete Review</a> |
                <a href="History.php">Customer Review</a>
            </td>
                    </tr>
                    </table>
            </td>
        </tr>
        
        <tr>
            <td colspan="2">
            <fieldset>
            <legend>Review</legend>
            <table>
            <tr>
                    <td>Customer Name</td>
                    <td><input type="text" name="cname"> </td>
                    
                </tr>
                <tr>
                   <td colspan="2"><hr></td> 
                </tr>
                <tr>
                    <td>Itemname</td>
                    <td><input type="text" name="itemname"> </td>
                    
                </tr>
                <tr>
                   <td colspan="2"><hr></td> 
                </tr>
                
                <tr>
                    <td>Review</td>
                    <td><input type="text" name="review"></td>
                </tr>
                <tr>
                    <td><input type="submit" name="submit" value="Submit"></td>
                </tr>

            </table>
            </td>
        </tr>
       
    </table>
    </center>
        
    </form>
</body>
</html>
<?php include '../views/footer.php' ?>

 