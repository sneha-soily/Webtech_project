<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Find Near Restaurant</title>
	<link rel="stylesheet" href="../views/css/history.css">
	<style>
	table {
	  font-family: arial, sans-serif;
	  border-collapse: collapse;
	  width: 100%;
	}

	td, th {
	  border: 1px solid #dddddd;
	  padding: 8px;
	}
	table, th, td {
        border: 1px solid goldenrod;
        border-collapse: collapse;
        padding: 1vw;
    }
    .reservationData:hover {
        background-color: goldenrod;
        color: black;
    }
    #button {
        background-color: black;
        border: none;
        text-decoration: none;
        color: goldenrod;
    }

</style>
</head>
<body>


<?php

include("../models/connection.php");

if(isset($_POST['input'])){

	$input = $_POST['input'];

	$query = "SELECT * FROM near WHERE Place_Name LIKE '{$input}%' OR Restaurant LIKE '{$input}%'";
	$result = mysqli_query($con,$query);

	if (mysqli_num_rows($result)>0) {?>
</center>
	<div class="container">
		<table class="table">
			<thead>
				<tr style="background-color: goldenrod;">
					<th>id</th>
					<th>Place_Name</th>
					<th>Address</th>
					<th>Restaurant</th>
				</tr>
			</thead>
		

		<tbody>
			<?php

			while($row = mysqli_fetch_assoc($result))
			{
				$id = $row['id'];
				$Place_Name = $row['Place_Name'];
				$Address = $row['Address'];
				$Restaurant = $row['Restaurant'];
				?>
					<tr style="text-align: center; font-size: 18px;" class="reservationData">
						<td><?php echo $id; ?></td>
						<td><?php echo $Place_Name; ?></td>
						<td><?php echo $Address; ?></td>
						<td><?php echo $Restaurant; ?></td>
					</tr>
				<?php

			}
			?>
		</tbody>
		</table>
	</div>
</center>
		<?php
	}else{
		echo "No data found";
	}
}

?>

</body>
</html>