<?php
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$time = $_POST['time'];

require_once "../../models/connection.php";

$connection = getConnection();
$sql = "INSERT INTO reservations (name, email_address, phone_number, time) VALUES ('{$name}', '{$email}', '{$phone}', '{$time}');";
mysqli_query($connection, $sql);
mysqli_close($connection);
echo "Insertion Successful";
