<?php

include("../models/connection.php");

if(isset($_POST['input'])){

	$input = $_POST['input'];

	$query = "SELECT * FROM near WHERE Place_Name LIKE '{$input}%' OR Restaurant LIKE '{$input}%'";
	$result = mysqli_query($con,$query);

	if (mysqli_num_rows($result)>0) {?>

		<table>
			<thead>
				<tr>
					<th>id</th>
					<th>Place_Name</th>
					<th>Address</th>
					<th>Restaurant</th>
				</tr>
			</thead>
		</table>

		<tbody>
			<?php

			while($row = mysqli_fetch_assoc($result))
			{
				$id = $row['id'];
				$Place_Name = $row['Place_Name'];
				$Address = $row['Address'];
				$Restaurant = $row['Restaurant'];
				?>
					<tr>
						<td><?php echo $id; ?></td>
						<td><?php echo $Place_Name; ?></td>
						<td><?php echo $Address; ?></td>
						<td><?php echo $Restaurant; ?></td>
					</tr>
				<?php

			}
			?>
		</tbody>
		
		<?php
	}else{
		echo "No data found";
	}
}

?>