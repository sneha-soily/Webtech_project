<?php
require_once "../../models/connection.php";

$reservationID = $_POST['reservationID'];
$connection = getConnection();
$sql = "DELETE FROM reservations WHERE reservation_id='{$reservationID}'";
$status = mysqli_query($connection, $sql);
echo "Reservation ID: $reservationID Deletion successful";