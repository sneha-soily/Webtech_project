<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Reserve Table</title>
    <link rel="stylesheet" href="../views/css/history.css">
</head>
<body>
<h1 style="text-align: center">Reserve Table</h1>
<br><br>
<fieldset>
    <legend><h3>Please provide your reserve time</h3></legend>
    <div id="reservation">


        <label for="name">Name</label>
        <input type="text" name="name" id="name" required>

        <br><br>

        <label for="email">Email</label>
        <input type="text" name="email" id="email" required>

        <br><br>

        <label for="Phone">Phone </label>
        <input type="text" name="phone" id="phone" required>

        <br><br>

        <label for="time">Time</label>
        <input type="time" name="time" id="time" required>

        <br><br>

        <input type="submit" name="submit" value="submit" onclick="ajax()">
    </div><br>
    <a href="show_all_reserved_table.php">Show all reserved table</a>
    <br><br>
    <a style="color:red" href="Dashboard.php">Go Back</a>
</fieldset>
<br><br>
<?php include('footer.php'); ?>
<script>
    function ajax()
    {
        let name = document.getElementById('name').value;
        let email = document.getElementById('email').value;
        let phone = document.getElementById('phone').value;
        let time = document.getElementById('time').value;

        let xhttp = new XMLHttpRequest();
        xhttp.open('POST', 'ajax/insert_reservation.php', true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send('name=' + name + '&email=' + email + '&phone=' + phone +'&time=' + time);
        xhttp.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                document.getElementById('reservation').innerHTML = this.responseText;
            }
        }
    }
</script>
</body>

</html>
