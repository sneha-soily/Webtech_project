<?php

	include '../models/order.php';
	if(isset($_GET['deleteid']))
	{
		$Serial_Id=$_GET['deleteid'];
		$sql="DELETE from converttable where Serial_Id=$Serial_Id";
		$result=mysqli_query($con,$sql);
		if($result)
		{
			header("location: OrderHistory.php");
			//echo "Deleted successfully";
		}else
		{
			//die(mysql_error($con));
		}
	}

?>