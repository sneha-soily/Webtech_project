<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Payment System</title>
</head>
<body>
	<form method="post" action="../controls/PaymentAction.php" novalidate>

	<legend><h1>Payement System</h1></legend>

	<fieldset>
		<br><br>

		<label for="ordertype">Order Type: </label>
		<select name="ordertype" id="ordertype" required>
			<option value="bkash"> Bkash</option>
			<option value="Cash"> Cash</option>
			<option value="card"> Credit Card</option>
		</select>
		<br><br>
		<label for="amount">Amount</label>
		<input type="amount" name="amount" id="amount" placeholder="Type your amount" required>

		<br><br><br>
			<input type="submit" name="Payment" value="Payment">

			<br><br>
	</fieldset>



</body>
</html>