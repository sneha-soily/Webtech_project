<?php
session_start();
$_SESSION['$Serial_Id'] = $_GET['updateid'];
?>

<!DOCTYPE html>
<html>
<head>
     <title>Order Page</title>
     <link rel="stylesheet" href="../views/css/history.css">

</head>
<body>
    <div class="order">
    
<center>
    <table  width="500px">
         <tr>
            <td>
                <table width="500px">
                    <tr>
            <td>
                <h3><b>Place Order</b></h3>
            </td>
            <td>
                <a href="../views/Dashboard.php">Home</a>
                <a href="../views/CancelOrder.php">Cancel Order</a>
                <a href="../views/OrderHistory.php">Order Added Table</a>
            </td>
                    </tr>
                    </table>
            </td>
        </tr>
        
        <tr>
            <td colspan="2">
               <fieldset>
               <legend>FOOD ITEMS</legend>
               <form action="updating_order.php" method="POST">
               <table>
               <tr>
                         <td>Customer Name</td>
                         <td><input type="text" name="cname"> </td>
                         
                    </tr>
                    <tr>
                   <td colspan="2"><hr></td> 
                </tr>
                  <tr>
                         <td>Customer Phone Number</td>
                         <td><input type="text" name="cnumber"> </td>
                         
                    </tr>
                    <tr>
                   <td colspan="2"><hr></td> 
                </tr>
                    <tr>
                         <td>Itemname</td>
                         <td><input type="text" name="itemname"> </td>
                         
                    </tr>
                    <tr>
                   <td colspan="2"><hr></td> 
                </tr>
                    
                    <tr>
                         <td>Quantity</td>
                         <td><input type="number" name="quantity"></td>
                    </tr>
                    <tr>
                   <td colspan="2"><hr></td> 
                </tr>
                    
                    <tr>
                         <td>Price</td>
                         <td><input type="text" name="price"></td>
                    </tr>
                    <tr>
                   <td colspan="2"><hr></td> 
                </tr>
               
                    
                <tr>
                    <td colspan="2">
                         <fieldset>
                         <legend>Drinks</legend>
                        <input type="radio" name="drinks" value="CocaCola"> CokaCola
                        <input type="radio" name="drinks" value="7up"> 7up
                        <input type="radio" name="drinks" value="Pepsi"> Pepsi
                    </fieldset>
                         <hr>
                         </td>
                </tr>

                    <tr>
                         <td><input type="submit" name="submit" value="update"></td>
                    </tr>

               </table>
               </form>

            </td>
        </tr>
       
    </table>
    </center>
          
     </form>
     </div>
</body>
</html>
<?php include '../views/footer.php' ?>

 