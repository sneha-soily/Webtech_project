<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Show Menu</title>
	<link rel="stylesheet" href="../views/css/Dashboard.css">
  <style>
    .head{
      border-bottom: 4px solid salmon;
    }

    .container .row .img img:hover{
      width: 104%;
    }

  </style>
</head>
<body>

  <h1 class="head">MENU</h1>

  <br>

  <div class="container">
    <div class="row">
      <div class="img">
        <img src="../views/css/Noodles.jpg">
        <h2>Noodles</h2>
        <h3>Price: 60tk</h3>
      </div>

      <div class="img">
        <img src="../views/css/ChickenBiriyani.jpg">
        <h2>Biriyani</h2>
        <h3>Price: 120tk</h3>
      </div>

      <div class="img">
        <img src="../views/css/Frenchfry.jpg">
        <h2>French Fry</h2>
        <h3>Price: 80tk</h3>
      </div>

    </div>

  </div>

  <div class="container">
    <div class="row">
      <div class="img">
        <img src="../views/css/Burger.jpg">
        <h2>Burger</h2>
        <h3>Price: 200tk</h3>
      </div>

      <div class="img">
        <img src="../views/css/1.jpg">
        <h2>Sandwich</h2>
        <h3>Price: 100tk</h3>
      </div>

      <div class="img">
        <img src="../views/css/2.jpg">
        <h2>Roll</h2>
        <h3>Price: 90tk</h3>
      </div>
    </div>

  </div>

  <div class="container">
    <div class="row">
      <div class="img">
        <img src="../views/css/3.jpg">
        <h2>Coffee</h2>
        <h3>Price: 70tk</h3>
      </div>

      <div class="img">
        <img src="../views/css/4.jpg">
        <h2>Platter</h2>
        <h3>Price: 220tk</h3>
      </div>

      <div class="img">
        <img src="../views/css/12.jpg">
        <h2>Strawbeery Juice</h2>
        <h3>Price: 110tk</h3>
      </div>
    </div>

  </div>

  <div class="container">
    <div class="row">
      <div class="img">
        <img src="../views/css/6.jpg">
        <h2>Pastry</h2>
        <h3>Price: 90tk</h3>
      </div>

      <div class="img">
        <img src="../views/css/7.jpg">
        <h2>Dessert</h2>
        <h3>Price: 75tk</h3>
      </div>

      <div class="img">
        <img src="../views/css/8.jpg">
        <h2>Soup</h2>
        <h3>Price: 120tk</h3>
      </div>
    </div>

  </div>

  <div class="container">
    <div class="row">
      <div class="img">
        <img src="../views/css/9.jpg">
        <h2>Cup Cake</h2>
        <h3>Price: 55tk</h3>
      </div>

      <div class="img">
        <img src="../views/css/10.jpg">
        <h2>Donut</h2>
        <h3>Price: 50tk</h3>
      </div>

      <div class="img">
        <img src="../views/css/11.jpg">
        <h2>Juice</h2>
        <h3>Price: 85tk</h3>
      </div>
    </div>

  </div>


<br><br>

  <div class="nav">
    <ul>
      <li><a href="../views/PlaceOrder.php">Now Order Food!</a></li>
      <li><a style="color:red" href="Dashboard.php">(Go back)</a><li>
    </ul>
    <br>
    
  </div>
<br><br>

</body>
</html>
