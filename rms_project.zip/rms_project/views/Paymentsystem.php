<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Payment System</title>
	<style>
		body{
			background: black;
			color: white;
			font-size: 18px;
		}
		input[type=text], select {
		  width: 25%;
		  padding: 12px 20px;
		  margin: 8px 0;
		  border: 1px solid #ccc;
		  border-radius: 4px;
		}

		input[type=submit] {
		  width: 25%;
		  background-color: #4CAF50;
		  color: white;
		  padding: 14px 20px;
		  margin: 8px 0;
		  border: none;
		  border-radius: 4px;
		  cursor: pointer;
		}

		input[type=submit]:hover {
		  background-color: #18491A;
		}

		div {
		  border-radius: 5px;
		  background-color: black;
		  padding: 20px;
		}

	</style>
</head>
<body>
	<div>
	<form method="post" action="../controls/PaymentAction.php" novalidate>

	<legend><h1>Payement System</h1></legend>
		<br><br>

		<label for="paymenttype">Payment Type: </label>
		<select name="paymenttype" id="paymenttype" required>
			<option value="bkash"> Bkash</option>
			<option value="Cash"> Cash</option>
			<option value="card"> Credit Card</option>
		</select>
		<br><br>
		<label for="amount">Amount</label>
		<input type="text" name="amount" id="amount" placeholder="Type your amount" required>

		<br><br>
		 <?php 

			if (isset($_GET['msg'])) {
			echo $_GET['msg'];
		}
		?>

		<br><br><br>
			<input type="submit" name="Payment" value="Payment">

			<br><br>
	<br><br>
	<a href="../views/Dashboard">Go back</a>



	<?php include('footer.php') ?>
	<br><br>
</div>
</body>
</html>