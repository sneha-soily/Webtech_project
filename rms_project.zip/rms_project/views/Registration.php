
<?php
session_start();
	include "../models/connection.php";
	include "../models/function.php";
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Registration Form</title>
	<link rel="stylesheet" href="../views/css/registration.css">
	<script type="js/registration.js"></script>

</head>
<body>
	<div class="container" >

	<div class="heading">Registration </div>

		<form name="regform" onsubmit="return validateForm();" action="../models/Registrationdb.php" method="POST">
		<div class="card-details">
		<div class="card-box">
			<label class="details" for="fname">First Name</label>
			<input type="text" name="firstname" id="fname" placeholder="Write your firstname" required>
			<span style= "color:red" id = "alert"></span>
		</div>
<br><br>
		<div class="card-box">
			<label class="details" for="lname">Last Name</label>
			<input type="text" name="lastname" id="lname" placeholder="Write your lastname" required>
		</div>
<br><br>
		<div class="card-box">
			<label class="details" for="gender">Gender: </label>
		    <input type="radio" name="gender" value="male"> Male <input type="radio" name="gender" value="female"> Female<br><span style= "color:red" id = "alert6"></span><br><br>
		</div>
<br><br>
		<div class="card-box">
			<label class="details" for="DOB">Date of Birth</label>
			<input type="date" name="DOB" id="DOB" value="DOB" required>
		</div>
<br><br>
		<div class="card-box">
			<label class="details" for="Address">Address</label>
			<textarea name="Address" id="Address" placeholder="Enter your address" required></textarea>	
		</div>
<br><br>
		<div class="card-box">
			<label class="details" for="Phone">Phone:</label>
			<input type="tel" name="Phone" id="Phone" placeholder="Enter your phone number">
		</div>
<br><br><br>
		<div class="card-box">
			<label class="details" for="Email">Email</label>
			<input type="Email" name="Email" id="Email" placeholder="Enter your email here" required><span style= "color:red" id = "alert1"></span>
		</div>
<br><br><br>
		<div class="card-box">
			<br>
			<label class="details" for="username">Username</label>
			<input type="text" name="username" id="username" placeholder="Maximum 8 character can be used" maxlength="8" required><span style= "color:red" id = "alert2"></span>
		</div>
<br><br>
		<div class="card-box">
			<label class="details" for="usertype">User Type: </label>
			<select class="details" name="usertype" id="usertype" required>
				<option value="Admin"> Admin</option>
				<option value="username"> Customer</option>
				<option value="Manager"> Manager</option>
				<option value="Employee"> Employee</option> 
			</select>
		</div>
<br><br>
		<div class="card-box">
			<label class="details" for="password">Password</label>
			<input type="password" name="password" id="password" placeholder="Type your password" required><span style= "color:red" id = "alert4"></span>
		</div>
<br><br>
		<div class="card-box">
			<label class="details" for="cfpassword">Confirm Password</label>
			<input type="password" name="cfpassword" id="cfpassword" placeholder="Confirm your password" required><span style= "color:red" id = "alert5"></span> 
		</div>

		<div style="text-align:center;" class="button">
			<input type="submit" name="submit" value="Register">
		</div>
	</form>
	</div>

	<?php if (isset($_GET['error'])) { ?>
			    <p class="error" style="color:red; font-size: 100%; font-weight: bold;"><?php echo $_GET['error']; ?></p><?php }?>
	<br>
		<a style="color: white;" href="../views/Login.php">Go back</a>
<br><br>
<script>
	
function validatename(){
    var ptrn = /^([^0-9]*)$/;
    var name = document.getElementById("fname");
    if(name.value ==""){
    document.getElementById("alert").innerHTML = "*Name can't be empty";
    
    }else if(!ptrn.test(document.regform.fname.value)){
        document.getElementById("alert").innerHTML = "*Name can't have digit";

    } else if(name.value.length<2){
        document.getElementById("alert").innerHTML = "*Name can't have less than 2 two digits";

    }else if(name.value.length>20){
        document.getElementById("alert").innerHTML = "*Name can't be more than 20 two digits";

    }else{
        document.getElementById("alert").innerHTML = "";
       
    } 

} document.regform.fname.addEventListener("keyup",validatename);


function validateemail(){
    var ptrn = /^[a-zA-Z\d\._]+@[a-zA-Z\d\._]+[\.][a-zA-Z\d\._]+$/;
    var Email = document.getElementById("Email");
    if(Email.value ==""){
    document.getElementById("alert1").innerHTML = "*Email can't empty";
    }else if(!ptrn.test(document.regform.Email.value)){
    document.getElementById("alert1").innerHTML = "*Wrong email formation";
    }else{
    document.getElementById("alert1").innerHTML = "";
    
    } 

} document.regform.Email.addEventListener("keyup",validateemail);

function validateusername(){
    var ptrn = /^[a-zA-z_0-9]*$/;
    var username = document.getElementById("username");
    if(username.value ==""){
    document.getElementById("alert2").innerHTML = "*Username can't be empty";
    
    }else if(!ptrn.test(document.regform.username.value)){
    document.getElementById("alert2").innerHTML = "*Only characters, alphabic numeric characters, dash, underscore can be used in username";    
    }else if(username.value.length<4){
    document.getElementById("alert2").innerHTML = "*Username can't have less than 4 two digits";
    }else if(username.value.length>15){
    document.getElementById("alert2").innerHTML = "*Username can't be more than 15 two digits";
    }else{
    document.getElementById("alert2").innerHTML = "";
    
    } 

} document.regform.username.addEventListener("keyup",validateusername);

function validatepassword(){
    var ptrn = /^[A-Z]+[a-zA-Z\d]+[a-zA-Z\d@$#%&(()?]+$/;
    var password = document.getElementById("password");
    if(password.value ==""){
    document.getElementById("alert4").innerHTML = "*Password can't be empty";
    }else if(ptrn.test(document.regform.user_name.value)){
    document.getElementById("alert4").innerHTML = "*Wrong password formation";
    }else if(password.value.length<8){
    document.getElementById("alert4").innerHTML = "*Password can't have less than 4 two digits";
    }else if(password.value.length>32){
    document.getElementById("alert4").innerHTML = "*Password can't be more than 15 two digits";
    }else{
    document.getElementById("alert4").innerHTML = "";
    
    } 
} document.regform.password.addEventListener("keyup",validatepassword);


function validateconfirmpassword(){
var cfpassword = document.getElementById("cfpassword");
var password = document.getElementById("password").value;
var confirmpassword = document.getElementById("cfpassword").value;
if(cfpassword.value == ""){
    document.getElementById("alert5").innerHTML = "This field can't be empty";
}
else if(password !=confirmpassword){
    document.getElementById("alert5").innerHTML = "Password didn't match";
}else{
    document.getElementById("alert5").innerHTML = "";
    
}
} document.regform.cfpassword.addEventListener("keyup",validateconfirmpassword);

function validategender(){
     
    if(document.getElementById("male").Checked){
        document.getElementById("alert6").innerHTML = "";

    }else if(document.getElementById("female").Checked){
        document.getElementById("alert6").innerHTML = "";

    }else if(document.getElementById("others").Checked){
        document.getElementById("alert6").innerHTML = "";

    }else{
        document.getElementById("alert6").innerHTML = "*Select your Gender";
        
    }
}

function validateForm() {
    let x = document.forms["regform"]["fname"].value;
    let xx = document.forms["regform"]["email"].value;
    let x1 = document.forms["regform"]["username"].value;
    let x2 = document.forms["regform"]["password"].value;
    let x3= document.forms["regform"]["cfpassword"].value;
    var ptrn = /^([^0-9]*)$/;
    var ptrn1 = /^[a-zA-Z\d\._]+@[a-zA-Z\d\._]+[\.][a-zA-Z\d\._]+$/;
        if (x == ""){
        document.getElementById("alert").innerHTML = "*Name must be filled out";
        return false}
        else if(xx ==""){
            document.getElementById("alert1").innerHTML = "*Email can't be empty";
            return false;}
        else if(x1 == ""){
            document.getElementById("alert2").innerHTML = "*Username can't be empty";
            return false;}
        else if(x2 ==""){
            document.getElementById("alert4").innerHTML = "*Password must be filled out";
            return false;
        }
        else if(x3==""){
        document.getElementById("alert5").innerHTML = "*this field must be filled out";
        return false;
        }else if(!ptrn.test(document.regform.fname.value)){
        document.getElementById("alert").innerHTML = "*Name can't have digit";
        return false;
        }else if(x.length<2){
            document.getElementById("alert").innerHTML = "*Name can't have less than 2 two digits";
            return false;
        }else if(!ptrn1.test(document.regform.Email.value)){
            document.getElementById("alert1").innerHTML = "*Wrong email formation";
            return false;
        }else if (x2 != x3){
            document.getElementById("alert5").innerHTML = "Password didn't match";
            return false;
        }
    
    
    
    
   
  }

</script>
</body>
</html>