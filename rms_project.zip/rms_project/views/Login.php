<?php
session_start();
include("../models/connection.php");
include("../models/function.php");

?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link rel="stylesheet" href="../views/css/registration1.css">

</head>
<body>
<form class="box" name="logform" onSubmit="return validateForm();" action="../controls/LoginAction.php" method="POST"
      novalidate>
    <div class="login-box">
        <h1 style="text-align: center;">Login Form</h1>

        <br><br>
        <div class="user-box">
            <label for="username"></label>
            <input type="text" name="username" id="username"
                   placeholder="Username" <?php if (isset($_COOKIE['username'])) {
                echo "value={$_COOKIE['username']}";
            } ?> required><span style="color:red"
                                id="alert2"></span>

        </div>
        <br><br>
        <div class="user-box">
            <label for="password"></label>
            <input type="password" name="password" id="password"
                   placeholder="Password" <?php if (isset($_COOKIE['password'])) {
                echo "value={$_COOKIE['password']}";
            } ?> required><span style="color:red"
                                id="alert4"></span>
        </div>

        <div class="check-box">
            <br>
            <input type="checkbox" name="remember_me" value="remembered">Remember me<br>
            <input type="submit" name="submit" value="Login">
        </div>
        <?php if (isset($_GET['error'])) { ?>
            <p class="error"
               style="color:red; font-size: 100%; font-weight: bold;"><?php echo $_GET['error']; ?></p><?php } ?>
        <br>
    </div>


    <div class="link">
        <label><a href="Registration.php">Registration</a></label>
        <label><a href="Forgetpass.php">Forget password!</a></label>
    </div>
    <script>
        function validateusername() {
            var ptrn = /^[a-zA-z_0-9]*$/;
            var username = document.getElementById("username");
            if (username.value == "") {
                document.getElementById("alert2").innerHTML = "*Username can't be empty";
            } else if (!ptrn.test(document.logform.username.value)) {
                document.getElementById("alert2").innerHTML = "*Only characters, alphabic numeric characters, dash, underscore can be used in username";
            } else if (username.value.length < 4) {
                document.getElementById("alert2").innerHTML = "*Username can't have less than 4 two digits";
            } else if (username.value.length > 15) {
                document.getElementById("alert2").innerHTML = "*Username can't be more than 15 two digits";
            } else {
                document.getElementById("alert2").innerHTML = "";

            }

        }

        document.logform.username.addEventListener("keyup", validateusername);


        function validatepassword() {
            var ptrn = /^[A-Z]+[a-zA-Z\d]+[a-zA-Z\d@$#%&(()?]+$/;
            var password = document.getElementById("password");
            if (password.value == "") {
                document.getElementById("alert4").innerHTML = "*Password can't be empty";
            } else if (ptrn.test(document.logform.username.value)) {
                document.getElementById("alert4").innerHTML = "*Wrong password formation";
            } else if (password.length < 8) {
                document.getElementById("alert4").innerHTML = "*Password can't have less than 8 two digits";
            } else if (password.length > 32) {
                document.getElementById("alert4").innerHTML = "*Password can't be more than 32 two digits";
            } else {
                document.getElementById("alert4").innerHTML = "";

            }
        }

        document.logform.password.addEventListener("keyup", validatepassword);

        function validateForm() {
            let x1 = document.forms["logform"]["username"].value;
            let x2 = document.forms["logform"]["password"].value;
            if (x1 == "") {
                document.getElementById("alert2").innerHTML = "*Name must be filled out";
                return false
            } else if (x2 == "") {
                document.getElementById("alert4").innerHTML = "*Password must be filled out";
                return false;
            } else if (x1.length < 4) {
                document.getElementById("alert2").innerHTML = "*Username can't have less than 4 two digits";
                return false;
            } else if (x1.length > 15) {
                document.getElementById("alert2").innerHTML = "*Username can't be more than 15 two digits";
                return false;
            } else if (x2.length < 8) {
                document.getElementById("alert4").innerHTML = "*Password can't be less than 8 two digits";
                return false;
            } else if (x2.length > 32) {
                document.getElementById("alert4").innerHTML = "*Password can't be more than 32 two digits";
                return false;
            }
        }

    </script>

</form>

</body>
</html>