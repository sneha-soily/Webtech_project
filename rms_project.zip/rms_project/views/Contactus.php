<?php
session_start();
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Contact Us</title>
	<style>
		body{
			background: black;
			color: white;
			font-size: 18px;
		}
		input[type=text]{
		  width: 25%;
		  padding: 12px 20px;
		  margin: 8px 0;
		  border: 1px solid #ccc;
		  border-radius: 4px;
		}

		input[type=submit] {
		  width: 25%;
		  background-color: #4CAF50;
		  color: white;
		  padding: 14px 20px;
		  margin: 8px 0;
		  border: none;
		  border-radius: 4px;
		  cursor: pointer;
		}

		input[type=submit]:hover {
		  background-color: #18491A;
		}

		div {
		  border-radius: 5px;
		  background-color: black;
		  padding: 20px;
		}

	</style>
</head>
<body>
		<form method="post" action="../controls/ContactustAction.php" novalidate>
			<h1>Contact Us</h1>
			<fieldset>
				<br><br>
				<label for="username">Username</label> 
				<input type="text" name="username" id="username" required>
				<br><br>
				<label for="email">Email</label>
				<input type="text" name="email" id="userEmail" required>
				<br><br>
				<label for="subject">Subject</label>
				<input type="text" name="subject" id="subject" required>
				<br><br>
				<label for="content">Message</label>
				<textarea name="content" id="content" cols="60" rows="6"></textarea>

		 		<?php 

				if (isset($_GET['msg'])) {
				echo $_GET['msg'];
				}
				?>

                
				<br><br>
				<input type="submit" name="send" value="Send" >
				<br><br>
		
		
		</fieldset>
		

		 <?php include("../views/footer.php")?>
	

</body>
</html>