<?php
include('../models/user.php');
include '../models/connection.php';
session_start();
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Change Password</title>
	<style>
		body{
			background: black;
			color: white;
			font-size: 18px;
		}
		input[type=password]{
		  width: 25%;
		  padding: 12px 20px;
		  margin: 8px 0;
		  border: 1px solid #ccc;
		  border-radius: 4px;
		}

		input[type=submit] {
		  width: 25%;
		  background-color: #4CAF50;
		  color: white;
		  padding: 14px 20px;
		  margin: 8px 0;
		  border: none;
		  border-radius: 4px;
		  cursor: pointer;
		}

		input[type=submit]:hover {
		  background-color: #18491A;
		}

		div {
		  border-radius: 5px;
		  background-color: black;
		  padding: 20px;
		}
		a:link, a:visited {
  			background-color: #CD5C5C;
			color: white;
			padding: 10px 20px;
			text-align: center;
			text-decoration: none;
		}

		a:hover, a:active {
  			background-color: #DC143C;
		}

	</style>
</head>
<body>
	<legend><h1>Change Password</h1></legend>
	<?php
	 if (isset($_POST['change_pass'])) {
	 	$currentpassword=$_POST['password'];
	 	$newpassword=$_POST['npassword'];
	 	$confirmpassword=$_POST['conpassword'];

	 	$sql="Select password from `user_form` where password='$password'";

        $result=mysqli_query($con,$sql);

        if ($result) {
          $row= mysqli_fetch_assoc($result);
          if (password_verify($currentpassword, $row['password'])) {
          	if ($confirmpassword=='') {
          		$error[]= 'please confirm the password';
          	}
          	if ($newpassword != $confirmpassword) {
          		$error[]= 'password do not match';
          	}
          }
          

          if (!isset($error)) {
          	$result=mysqli_query($con,"UPDATE user_form SET password=$newpassword, cpassword=$newpassword WHERE password='$currentpassword'");
          	if ($result) {
          		header("location: changepass.php?password_updated=1");
          	}
          	else{
          		$error[]='Somthing went worng';
          	}
          	
        }
          
        }
        else
        {
        	$error[]= 'current password do not match';
        }

	}

	?>
<div>
	<form name="regform" onsubmit="return validateForm();" method="post" action="">
		
		<label>Current Password:</label>
		<input type="password" name="password">
	   
	    <br><br>

		<label>New  Password:</label>
		<input type="password" name="npassword">
		<span style= "color:red" id = "alert4"></span>
		<br><br>

		<label>Confirm Password:</label>
		<input type="password" name="conpassword">
		<span style= "color:red" id = "alert5"></span>
		<br><br>
		
		<input type="submit" name="change_pass" value="Submit"></input>

		<br><br>
		
	</form>

<script>
	
function validatepassword(){

    var ptrn = /^[A-Z]+[a-zA-Z\d]+[a-zA-Z\d@$#%&(()?]+$/;
    var npassword = document.getElementById("npassword");
    if(npassword.value ==""){
    document.getElementById("alert4").innerHTML = "*Password can't be empty";
    }else if(ptrn.test(document.regform.user_name.value)){
    document.getElementById("alert4").innerHTML = "*Wrong password formation";
    }else if(npassword.value.length<8){
    document.getElementById("alert4").innerHTML = "*Password can't have less than 4 two digits";
    }else if(npassword.value.length>32){
    document.getElementById("alert4").innerHTML = "*Password can't be more than 15 two digits";
    }else{
    document.getElementById("alert4").innerHTML = "";
    
    } 
} document.regform.npassword.addEventListener("keyup",validatepassword);


function validateconfirmpassword(){

var conpassword = document.getElementById("conpassword");
var npassword = document.getElementById("npassword").value;
var confirmpassword = document.getElementById("conpassword").value;
if(conpassword.value == ""){
    document.getElementById("alert5").innerHTML = "This field can't be empty";
}
else if(npassword !=confirmpassword){
    document.getElementById("alert5").innerHTML = "Password didn't match";
}else{
    document.getElementById("alert5").innerHTML = "";
    
}
} document.regform.conpassword.addEventListener("keyup",validateconfirmpassword);


function validateForm() {

    let x2 = document.forms["regform"]["npassword"].value;
    let x3= document.forms["regform"]["conpassword"].value;
    var ptrn = /^([^0-9]*)$/;
    var ptrn1 = /^[a-zA-Z\d\._]+@[a-zA-Z\d\._]+[\.][a-zA-Z\d\._]+$/;
        if(x2 ==""){
            document.getElementById("alert4").innerHTML = "*Password must be filled out";
            return false;
        }
        else if(x3==""){
        document.getElementById("alert5").innerHTML = "*this field must be filled out";
        return false;
        }else if (x2 != x3){
            document.getElementById("alert5").innerHTML = "Password didn't match";
            return false;
        } 
   
  }


</script>
	<h3><a href="Dashboard.php">Back</a></h3>

	</div>	

	
</body>
</html>



<?php include('footer.php'); ?>