<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Reserve Table</title>
    <link rel="stylesheet" href="../views/css/history.css">
</head>
<style>
    table, th, td {
        border: 1px solid goldenrod;
        border-collapse: collapse;
        padding: 1vw;
    }
    .reservationData:hover {
        background-color: goldenrod;
        color: black;
    }
    #button {
        background-color: black;
        border: none;
        text-decoration: none;
        color: goldenrod;
    }
    
</style>
<body>
<h1 style="text-align: center">Reserve Table</h1>
<br><br>
<fieldset>
    <legend><h3>Please provide your reserve time</h3></legend>
    <div id="reservation">
        <table>
            <tr>
                <th>Reservation ID</th>
                <th>Name</th>
                <th>Email Address</th>
                <th>Phone number</th>
                <th>Time</th>
            </tr>
            <?php
            require_once "../models/connection.php";
            $connection = getConnection();
            $sql = "SELECT * FROM reservations";
            $reservations = mysqli_query($connection, $sql);
            while ($reservation = mysqli_fetch_array($reservations)) {
                echo "<div id='reservation_table'>";
                echo "<tr class='reservationData'>";
                echo "<td>{$reservation[0]}</td>";
                echo "<td>{$reservation[1]}</td>";
                echo "<td>{$reservation[2]}</td>";
                echo "<td>{$reservation[3]}</td>";
                echo "<td>{$reservation[4]}</td>";
                echo "<td><input type='button' id='button' name='Delete' value='Delete' onclick='deleteReservation({$reservation[0]})'/></td>";
                echo "</tr>";
                echo "</div>";

            }
            ?>
        </table>
    </div><br>
    <a href="reserveTable.php">Insert Reservations</a>
    <br><br>
    <a href="show_all_reserved_table.php">Show all reserved table</a>
    <br><br>
    <a style="color: red;" href="Dashboard.php">Go Back</a>
</fieldset>
<br><br>
<?php include('footer.php'); ?>
<script>
    function deleteReservation(reservationID) {
        let xhttp = new XMLHttpRequest();
        xhttp.open('POST', 'ajax/delete_reservation.php', true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send('reservationID=' + reservationID);
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById('reservation').innerHTML = this.responseText;
            }
        }
    }
</script>
</body>

</html>
