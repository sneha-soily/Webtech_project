<?php 

include ('../models/user.php');
include ('../models/connection.php');

if(isset($_POST['submit']))
{
	$firstname =$_POST['firstname'];
 	$lastname = $_POST['lastname'];
 	$gender =$_POST['gender'];
 	$DOB = $_POST['DOB'];
 	$Address = $_POST['Address'];
 	$Phone = $_POST['Phone'];
 	$Email = $_POST['Email'];
 	$username = $_POST['username'];
 	$usertype = $_POST['usertype'];
 	$password = $_POST['password'];

  if (in_array($file_extension,$extension)) {
   
    $sql="insert into user_form (firstname, lastname, gender, DOB, address, phone, email, username, usertype, password, cpassword) values ('$firstname','$lastname','$gender','$DOB','$Address','$Phone','$Email','$username','$usertype','$password')";
    $result=mysqli_query($conn,$sql);
    if ($result) {
      echo '<strong>Successfully</strong>';
    }
    else
    {
      die(mysqli_error($conn));
    }


  }
}

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Profile</title>
  <link rel="stylesheet" href="">
</head>

<body>
	<h1>Profile</h1>
<fieldset>
<legend><b>User Profile</b></legend>
  <table>
  <thead>
    
  </thead>
  <tbody>
  <?php 
	$sql="Select * from `user_form` order by id desc";
	$result=mysqli_query($conn,$sql);
	$row=mysqli_fetch_assoc($result);
	$id=$row['id'];
	$firstname =$row['firstname'];
 	$lastname = $row['lastname'];
 	$gender =$row['gender'];
 	$DOB = $row['DOB'];
 	$Address = $row['address'];
 	$Phone = $row['phone'];
 	$Email = $row['email'];
 	$username = $row['username'];
 	$usertype = $row['usertype'];
 	$password = $row['password'];

echo '
      <tr><td>'."<label>First Name : </label> ".$firstname.'</td></tr>
      <tr><td>'."<label>Last Name : </label> ".$lastname.'</td></tr>
      <tr><td>'."<label>Gender : </label> ".$gender.'</td></tr>
      <tr><td>'."<label>Date of Birth: </label> ".$DOB.'</td></tr>
      <tr><td>'."<label>Address : </label> ".$Address.'</td></tr>
      <tr><td>'."<label>Phone : </label> ".$Phone.'</td></tr>
      <tr><td>'."<label>Email : </label> ".$Email.'</td></tr>
      <tr><td>'."<label>Username : </label> ".$username.'</td></tr>
      <tr><td>'."<label>Usertype : </label> ".$usertype.'</td></tr>
      <tr><td>'."<label>First Name : </label> ".$password.'</td></tr>
      <tr><td><a href=homepage.php>Back</a></td></tr>';

 ?>
  
  </tbody>
</table><br><br>
</center>


<br><br>

</div>
</body>
</html>