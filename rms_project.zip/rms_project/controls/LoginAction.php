<?php
session_start();
require '../models/user.php';

if ($_SERVER['REQUEST_METHOD'] === "POST") {

    $username = sanitize($_POST['username']);
    $password = sanitize($_POST['password']);
    $isValid = true;
    if (empty($username)) {
        $_SESSION['username_msg'] = "Username cannot be empty";
        $isValid = false;
    }
    if (empty($password)) {
        $_SESSION['password_msg'] = "Password cannot be empty";
        $isValid = false;
    }

    if ($isValid === true) {

        $isValid = false;

        if (credentials($username, $password)) {
            $isValid = true;
        } else {
            $_SESSION['global_msg'] = "No record(s) found. Please contact with the administrator";
            header("Location: ../views/Login.php");
        }
        $conn = getConnection();
        mysqli_close($conn);

        if ($isValid) {
            $_SESSION['username'] = $username;
            if ($_POST['remember_me'] == "remembered") {
                setcookie('username', $username, time() + 3600, '/');
                setcookie('password', $password, time() + 3600, '/');
            }
            header("Location: ../views/Dashboard.php");
        } else {
            $_SESSION['global_msg'] = "Username or password incorrect";
            header("Location: ../views/Login.php");
        }
    } else {
        header("Location: ../views/Login.php");
    }
} else {
    $_SESSION['global_msg'] = "Something went wrong";
    header("Location: ../views/Login.php");
}


function sanitize($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    return htmlspecialchars($data);
}