<?php 	
		
	if ($_SERVER['REQUEST_METHOD'] === "POST") {
		
		if (empty($_POST['username']) || empty($_POST['content'])){
			header("Location: ../views/Contactus.php? msg=Please fill up the form properly");
		}
		else {
			
			echo "Submited Successfully!";
		}	
	}
	else {
		/*echo "Invalid Request";*/

		header("Location: error.html");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Contact Us</title>
	<style>
		body{
			background: black;
			color: white;
			font-size: 16px;
		}
		a:link, a:visited {
  			background-color: #CD5C5C;
			color: white;
			padding: 10px 20px;
			text-align: center;
			text-decoration: none;
		}

		a:hover, a:active {
  			background-color: #DC143C;
		}
</style>
</head>
<body>
	
	<br><br>
	<a href="../views/Dashboard.php">Go back</a>



	<?php include('../views/footer.php') ?>
	<br><br>

</body>
</html>