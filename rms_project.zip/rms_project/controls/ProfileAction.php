<?php 	
		
	if ($_SERVER['REQUEST_METHOD'] === "POST") {
		
		if (empty($_POST['image']) || empty($_POST['fname'])||empty($_POST['lname'])||empty($_POST['address'])||empty($_POST['div'])||empty($_POST['dis'])) {
			header("Location: ../views/Profile.php?msg=Please fill up the form properly");
		}
		else {
			echo $_POST['image'] . " " . $_POST['fname']." ".$_POST['lname']. " ". $_POST['address']." ".$_POST['div']. " ".$_POST['dis'];
		}	
	}
	else {
		/*echo "Invalid Request";*/

		header("Location: error.html");
	}
?>