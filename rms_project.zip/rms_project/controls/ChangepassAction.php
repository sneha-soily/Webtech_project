<?php 	
		
	if ($_SERVER['REQUEST_METHOD'] === "POST") {
		
		if (empty($_POST['email']) || empty($_POST['password'])||empty('cfpassword')||empty('rpassword')) {
			header("Location:../views/Changepass.php?msg=Please fill up the form properly");
		}
		else {
			
			echo $_POST['email'] . " " . $_POST['password']." ".$_POST['cfpassword']. " ". $_POST['rpassword'];
			echo "<br><br>";
			echo "Change Successfully!";
		}	
	}
	else {
		/*echo "Invalid Request";*/

		header("Location: error.html");
	}
?>