<?php 	
		
	if ($_SERVER['REQUEST_METHOD'] === "POST") {
		
		if (empty($_POST['username']) || empty($_POST['usertype'])) {
			header("Location: ../views/Login.php?msg=Please fill up the form properly");
		}
		else {
			echo "Verification successfully";
		}	
	}
	else {
		/*echo "Invalid Request";*/

		header("Location: error.html");
	}
?>