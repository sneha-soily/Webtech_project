<?php 
include '../models/order.php';
if(isset($_POST['submit']))
{

  $cname=$_POST['cname'];
  $itemname=$_POST['itemname'];
  $review=$_POST['review'];

  $sql="insert into `reviewtable` (Customer_Name,Itemname,Review) values('$cname','$itemname','$review')";
  $result=mysqli_query($con,$sql);

  if($result)
  {
    echo "Data inserted successfully";
  }
  else
  {
    die(mysqli_error($con));
  }


}

?>




<!DOCTYPE html>
<html>
<head>
    <title>Review Page</title>
    <style>
        body{
            background: black;
            color: white;
            font-size: 16px;
        }
    </style>
    <script type="../views//js/review.js"></script>

</head>
<body>
    <form name="regform" onsubmit="return validateForm();" method="post" action="../controls/index.php">
            <center>
    <table  width="500px">
        <tr>
            <td>
                <table width="500px">
                    <tr>
                        <td align="Left">
                <h3><b>Customer Review</b></h3>
            </td>
            <td align="Right">
                <a href="../views/Dashboard.php">Home</a> |
                <a href="../views/History.php">Delete Review</a> |
                <a href="../views/History.php">Customer Review</a>
            </td>
                    </tr>
                    </table>
            </td>
        </tr>
        
        <tr>
            <td colspan="2">
            <fieldset>
            <legend>Review</legend>
            <table>
            <tr>
                    <td>Customer Name</td>
                    <td><input type="text" name="cname"> </td>
                    <span style= "color:red" id = "alert"></span>
                </tr>
                <tr>
                   <td colspan="2"><hr></td> 
                </tr>
                <tr>
                    <td>Itemname</td>
                    <td><input type="text" name="itemname"> </td>
                    <span style= "color:red" id = "alert1"></span>
                </tr>
                <tr>
                   <td colspan="2"><hr></td> 
                </tr>
                
                <tr>
                    <td>Review</td>
                    <td><input type="text" name="review"></td>
                    <span style= "color:red" id = "alert2"></span>
                </tr>
                <tr>
                    <td><input type="submit" name="submit" value="Submit"></td>
                </tr>

            </table>
            </td>
        </tr>
       
    </table>
    </center>
        
    </form>
    <script>
    function validatename(){

    var ptrn = /^([^0-9]*)$/;
    var name = document.getElementById("cname");
    if(name.value ==""){
    document.getElementById("alert").innerHTML = "*Name can't be empty";
    
    }else if(!ptrn.test(document.regform.fname.value)){
        document.getElementById("alert").innerHTML = "*Name can't have digit";

    } else if(name.value.length<2){
        document.getElementById("alert").innerHTML = "*Name can't have less than 2 two digits";

    }else if(name.value.length>20){
        document.getElementById("alert").innerHTML = "*Name can't be more than 20 two digits";

    }else{
        document.getElementById("alert").innerHTML = "";
       
    } 

} document.regform.fname.addEventListener("keyup",validatename);

function itemName() {
    var itemname = document.getElementById('itemname');
    if(itemname.value==""){
        document.getElementById("alert").innerHTML = "*Item name can't be empty";
    }

} document.regform.itemname.addEventListener("keyup",itemName);

function reviewValid() {
    var review = document.getElementById('review');
    if(review.value==""){
        document.getElementById("alert2").innerHTML = "*Please add review about our food!";
    }

} document.regform.review.addEventListener("keyup",reviewValid);

function validateForm() {

    let x = document.forms["regform"]["cname"].value;
    let xx = document.forms["regform"]["itemname"].value;
    let xxx = document.forms["regform"]["review"].value;
        if (x == ""){
        document.getElementById("alert").innerHTML = "*Name must be filled out";
            return false}
        else if(xx ==""){
            document.getElementById("alert1").innerHTML = "*Item name can't be empty";
            return false;}
        else if(xxx ==""){
            document.getElementById("alert2").innerHTML = "*Please add review about our food!";
            return false;}
   
  }
    </script>
</body>
</html>
<?php include '../views/footer.php' ?>